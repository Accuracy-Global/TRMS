import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from "rxjs";
import { Router } from '@angular/router';
import * as moment from 'moment';
@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private apiUrlLogin = environment.api +'login';

  private apiGetBranch = environment.api + 'get_branch_info';
  private apiGetRoomType = environment.api + 'get_room_type';
  private apiUrlCheckAvailability = environment.api +'check_availability';
  private apiUrlAddBooking = environment.api +'hotel_booking';
  private apUrlApiBid = environment.api + 'api/bid';
  constructor(private http:HttpClient) { }

  login(formData): Observable<any> {
    // console.log(formData);
    let requestData: any = [];

    requestData = {};
    requestData = { 
         email_id: formData.name,
         password: formData.password
    };    
    // console.log(requestData); 
    return this.http.post(this.apiUrlLogin, requestData);
  }

  getBranches(){
    return this.http.get(this.apiGetBranch);
  }

  getRoomType(){
    return this.http.get(this.apiGetRoomType);
  }

  checkAvailability(formData): Observable<any> {
    // console.log(formData);
    let requestData: any = [];

    requestData = {};
    requestData = { 
         checkindate: moment(formData.checkIn).format("YYYY-MM-DD"),
         branch: formData.branch,
         room_type: formData.room_type
    };    
    // console.log(requestData); 
    return this.http.post(this.apiUrlCheckAvailability, requestData);
  }

  addBooking(formData): Observable<any> {
    console.log(formData);
    let requestData: any = [];

    requestData = {};
    requestData = { 
         booking_name: formData.name,
         gender: formData.gender,
         email_id: formData.email,
         mobile: "+91"+formData.mobile,
         address: formData.address,
         checkindate: moment(formData.checkin).format('YYYY/MM/DD'),
         checkoutdate: moment(formData.checkout).format('YYYY/MM/DD'),
         adults: formData.adults.toString(),
         childrens: formData.childrens.toString(),
         rooms: formData.rooms,
         rent: parseInt(formData.rent).toString(),
         branch: formData.branch,
         room_type: formData.room_type
    };     
    return this.http.post(this.apiUrlAddBooking, requestData);
  }

  apiBidPayment(bookingId, mailId): Observable<any>{
    let requestData = {};
    requestData = {
        booking_id: bookingId,
        email_id: mailId
    } 
    
    return this.http.post(this.apUrlApiBid, requestData);
  }

}
