import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../auth.service';
import swal from 'sweetalert2';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  hide = true;
  login:FormGroup;
  lognRes:any;
  constructor(private formBuilder:FormBuilder, 
              private httpService:AuthService,
              private router:Router) { }

  ngOnInit() {
    document.querySelector('body').classList.add('body-bg-color-theme');
    
    this.login = this.formBuilder.group({
      name:['', [Validators.required, Validators.email]],
      password:['', [Validators.required]]
    })
  }

  get f(){
    return this.login.controls;
  }

  onSubmit(model:FormGroup){
    console.log(model.value);
    this.httpService.login(model.value).subscribe(res => {
    this.lognRes = res; 
    sessionStorage.setItem('userdata', JSON.stringify(this.lognRes.data[0]));

    console.log(this.lognRes);
    swal.fire(
      'success',
      'Logged In Successfully',
      'success'
    ).then(()=>{
      this.router.navigate(['/booking']);
    })
    },
    error => {
      swal.fire(
        'Failes!',
        error,
        'error'
      )
    });
  }

}
