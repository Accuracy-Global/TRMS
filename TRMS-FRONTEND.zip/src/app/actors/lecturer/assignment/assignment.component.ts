import { Component, OnInit } from '@angular/core';

export interface PeriodicElement {
  name: string;
  semester: string;
  assignment: string;
  topic: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  { name: 'John', semester: 'First', assignment: 'Assigned', topic: 'Physics' },
  { name: 'Nelson', semester: 'Second', assignment: 'Not Assigned', topic: 'Physics'},
  { name: 'Daisy', semester: 'Second', assignment: 'Not Assigned', topic: 'Physics'},
  { name: 'John', semester: 'Second', assignment: 'Assigned', topic: 'Mathematics'},
  { name: 'Rahul Nayar', semester: 'First', assignment: 'Assigned', topic: 'Physics'},
  { name: 'Nelson', semester: 'First', assignment: 'Assigned', topic: 'Physics'},
  { name: 'Daisy', semester: 'First', assignment: 'Assigned', topic: 'Physics'},
  { name: 'Rahul Nayar', semester: 'Second', assignment: 'Assigned', topic: 'Mathematics'},
  { name: 'Ramya Sheir', semester: 'First', assignment: 'Assigned', topic: 'Physics'},
  { name: 'Ramya Sheir', semester: 'Seconf', assignment: 'Not Assigned', topic: 'Physics'},
];

/**
 * @title Basic use of `<table mat-table>`
 */
@Component({
  selector: 'app-assignment',
  templateUrl: './assignment.component.html',
  styleUrls: ['./assignment.component.css']
})
export class LecturerAssignmentComponent implements OnInit {
  displayedColumns: string[] = [ 'name', 'semester', 'assignment', 'topic'];
  dataSource = ELEMENT_DATA;
  constructor() { }

  ngOnInit() {
  }

}
