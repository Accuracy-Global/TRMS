import { Component, OnInit } from '@angular/core';

export interface PeriodicElement {
  name: string;
  position: number;
  semester: string;
  result: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {position: 1, name: 'John', semester: 'First', result: '90%'},
  {position: 2, name: 'Nelson', semester: 'Second', result: '85%'},
  {position: 3, name: 'Daisy', semester: 'Second', result: '83%'},
  {position: 4, name: 'John', semester: 'Second', result: '89%'},
  {position: 5, name: 'Rahul Nayar', semester: 'First', result: '76%'},
  {position: 6, name: 'Nelson', semester: 'First', result: '75%'},
  {position: 7, name: 'Daisy', semester: 'First', result: '95%'},
  {position: 8, name: 'Rahul Nayar', semester: 'Second', result: '85%'},
  {position: 9, name: 'Ramya Sheir', semester: 'First', result: '98%'},
  {position: 10, name: 'Ramya Sheir', semester: 'Seconf', result: '98%'},
];

/**
 * @title Basic use of `<table mat-table>`
 */
@Component({
  selector: 'app-result',
  templateUrl: './result.component.html',
  styleUrls: ['./result.component.css']
})
export class ResultComponent implements OnInit {
  displayedColumns: string[] = ['position', 'name', 'semester', 'result'];
  dataSource = ELEMENT_DATA;
  constructor() { }

  ngOnInit() {
  }

}
