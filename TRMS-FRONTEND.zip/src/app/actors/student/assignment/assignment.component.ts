import { Component, OnInit } from '@angular/core';
import { Assignment } from './../../../model/assignment';

export interface PeriodicElement {
  name: string;
  subject: string;
  topic: string;
  date: string;
  status: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  { name: 'Mr James Williams', subject: 'Physics',  topic: 'Kinetic Enenrgy', date:'15/09/2020', status:'submitted' },
  { name: 'Mr James Williams', subject: 'Physics',  topic: 'Laws of Action', date:'25/09/2020', status:'submitted'},
  { name: 'Mr James Williams', subject: 'Physics',  topic: 'Magnetic Materials', date:'01/10/2020', status:'pending'},
  { name: 'Ms Sophia', subject: 'Mathematics',  topic: 'Ratios', date:'25/09/2020', status:'submitted'},
  { name: 'Ms Sophia', subject: 'Mathematics',  topic: 'Time and Work', date:'10/10/2020', status:'pending'},
];

/**
 * @title Basic use of `<table mat-table>`
 */
@Component({
  selector: 'app-assignment',
  templateUrl: './assignment.component.html',
  styleUrls: ['./assignment.component.css']
})
export class StudentAssignmentComponent implements OnInit {
  displayedColumns: string[] = [ 'name', 'subject', 'topic', 'date', 'status'];
  dataSource = ELEMENT_DATA;
  
  constructor() { }

  ngOnInit() {
  }

}
