import { Component, OnInit, TemplateRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from 'src/app/services/auth.service';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
// import swal from 'sweetalert2';
import swal from 'sweetalert2/dist/sweetalert2.all.js';
import { Router } from '@angular/router';

@Component({
  selector: 'app-availabilty',
  templateUrl: './availabilty.component.html',
  styleUrls: ['./availabilty.component.css']
})
export class AvailabiltyComponent implements OnInit {
  modalRef: BsModalRef;
  public checkAvailability: FormGroup;
  public booking: FormGroup;
  roomType:any[];
  branchList:any[];
  data:any[];
  minDate: Date;
  checkoutMinDate: Date;
  constructor(private httpService:AuthService, private fb:FormBuilder, 
    private modalService: BsModalService, private router:Router) { this.minDate = new Date(); }

  get f() { return this.checkAvailability.controls; }
  get g() { return this.booking.controls; }
  
  ngOnInit() {

    this.checkAvailability = this.fb.group({
      checkIn: ['', [Validators.required]],
      room_type: ['', [Validators.required]],
      branch: ['', [Validators.required]]
    });

    this.booking = this.fb.group({
      name: ['', [Validators.pattern('^[a-zA-Z \-\']+')]],
      gender: ['', [Validators.required]],
      email: ['', [Validators.required, Validators.email]],
      mobile: ['', [Validators.required]],
      address: ['', [Validators.required]],
      checkin: ['', [Validators.required]],
      checkout: ['', [Validators.required]],
      adults: ['', [Validators.required]],
      childrens: ['', [Validators.required]],
      rooms: ['', [Validators.required]],
      branch: ['', [Validators.required]],
      room_type: ['', [Validators.required]],
      rent:['',[Validators.required]]
    });

    this.getRoomsList();
    this.getBranchList();
  }

  getRoomsList(){
    this.roomType = [];
    this.httpService.getRoomType().subscribe( response => {
      this.roomType = response['data'];
      console.log(this.roomType);
    })
  }
  
  getBranchList(){
    this.branchList = [];
    this.httpService.getBranches().subscribe( response => {
      this.branchList = response['data'];
      console.log(this.branchList);
    })
  }

  openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template, {class: 'modal-lg'});
  } 

  onValueChange(value: Date){
    console.log(value);
    this.checkoutMinDate = value;
  }

  onChangeRoomType(event){
    console.log(event);
    console.log(this.roomType);
    let selectedType = this.roomType.filter(item => {
        return item.room_type == event;
    })
    console.log(selectedType);
    this.booking.controls['adults'].patchValue(selectedType[0].adult);
    this.booking.controls['childrens'].patchValue(selectedType[0].children);
  }
  
  showContent(item){
    console.log(item);
    console.log(item.amount);
    this.booking.controls['room_type'].patchValue(item.room_type);
    this.booking.controls['branch'].patchValue(item.branch);
    this.booking.controls['rent'].patchValue(item.amount);
    this.booking.controls['rooms'].patchValue('1');
    this.onChangeRoomType(item.room_type);
  }

  onSubmitCheckAvailability(model: FormGroup){
    // this.data = [];
    // let availValues = model.value;
    // availValues.checkIn = moment(availValues.checkIn).local().format("YYYY-MM-DD");
    // console.log(availValues);
    // this.spinner.show();
    this.httpService.checkAvailability(model.value).subscribe( response => {
      console.log(response);
      // this.spinner.hide();
      this.data = response['data'];
      // this.data.push({product_image : 'assets/img/images.jpg'});
      // console.log(this.data);

    //   for(let j = 0; j < this.data.length; j++){
    //     this.data[j]['product_image'] = "assets/img/images.jpg";
    //   }
    //   console.log(this.data);
      if(this.data === undefined || this.data.length == 0){
        // this.spinner.hide();
        swal.fire(
          'Failes!',
          'Rooms Not Available',
          'error'
        ).then(() => {
          
        }); 
    }
  },
  error => {
    console.log(error);
  },
  );
  
  
  }



  addBooking(model: FormGroup){
    // this.spinner.show();
   console.log(model.value);
  this.httpService.addBooking(model.value).subscribe((res) =>{
    console.log(res);
    // this.spinner.hide();
    if(res.status == true){
      swal.fire(
        'booked Sucessfully!.',
        'payment opens in next page',
        'success'
      ).then(() => {
        // location.reload();
        // this.router.navigate(['/student/dashboard']);
        this.paymentBid(res.booking_id, res.email_id);
        location.reload();
      });
      // this.paymentBid(res.booking_id, res.email_id);
      // this.router.navigate(['/']);

    }
   
  },
  error => {
    // this.spinner.hide();
    swal.fire(
      'Failes!',
       error,
      'error'
    ).then(() => {
      location.reload();
      // this.router.navigate(['/']);
    });  
   });

  
}

paymentBid(bookingId, mailId){
this.httpService.apiBidPayment(bookingId, mailId).subscribe( response => {
  console.log(response);
  // this.spinner.hide();
  console.log(response.responseData.payment_request.longurl);
  window.open(response.responseData.payment_request.longurl, '_blank');

});
}

}
