import { Component, OnInit } from '@angular/core';

export interface PeriodicElement {
  name: string;
  position: number;
  semester: string;
  result: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {position: 1, name: 'James Williams', semester: 'First', result: '90%'},
  {position: 2, name: 'Nelson', semester: 'Second', result: '85%'}
];

/**
 * @title Basic use of `<table mat-table>`
 */
@Component({
  selector: 'app-result',
  templateUrl: './result.component.html',
  styleUrls: ['./result.component.css']
})
export class StudentResultComponent implements OnInit {
  displayedColumns: string[] = ['position', 'name', 'semester', 'result'];
  dataSource = ELEMENT_DATA;
  constructor() { }

  ngOnInit() {
  }

}
