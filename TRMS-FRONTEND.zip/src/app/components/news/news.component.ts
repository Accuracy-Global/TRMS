import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material';
import * as Materialize from '../../../assets/js/materialize.min.js';
import { News } from '../../model/news';
import { NewsDialogComponent } from '../dialog/news/news.component';

@Component({
  selector: 'news',
  templateUrl: './news.component.html',
  styleUrls: ['./news.component.css']
})
export class NewsComponent implements OnInit {

  news: News[];
  options:Object;

  constructor(private dialog: MatDialog) { }

  ngOnInit() {
    this.options = {
      padding: 10,
      numVisible: 5,
      fullWidth: true
    };

    this.news = [
      { 
        title: "Python edges C++ for Tiobe’s programming language of the year", 
        body: `Tiobe index of programming language popularity identified Python and C++ as the languages with the greatest increases in popularity in 2020. For the fourth time, Python has won Tiobe’s programming language of the year award, given to the language gaining the most popularity in one year.

        In winning the designation for 2020, Python jumped 2.01 percentage points last year in the Tiobe Index of language popularity, edging out C++, which increased 1.99 percentage points. Easy-to-learn Python, Tiobe said, has become the favorite in fields such as machine learning and data science while 
        
        also being used for web development, back-end programming, mobile applications, and embedded systems. Overall, Python remains the third most popular language behind C and Java in the January 2021 edition of the index, which is based on a formula assessing searches in popular search engines. Python had 
        
        leapfrogged Java for second place in the November index but fell back to third place in December. `,
        date: new Date().toLocaleString(),
        category: "news"
      },
      { 
        title: "Angular Blog - Developer Survey 2020 Results", 
        body: `Earlier this year, we ran our annual developer survey. We want to thank you for the close to 30k responses, which will help us make Angular better! This post discusses the results we received and how they connect to the projects on the roadmap.
        
        In the survey, we asked a couple of closed and open-ended questions then analyzed all the input we got. We’re happy that over 50% of developers scored Angular with 9 or 10 out of 10 and less than 6% gave the platform less than 5 rating. Now let’s dig into some of the feedback!
        
        We ran the survey right after our version 9 release, which introduced the most significant changes since we originally published Angular in 2016. Thanks to the enormous test coverage we’re getting from the over 2,600 Angular projects in Google, we had high confidence in backward compatibility.
        
        At the same time, given the scale of the changes Ivy introduced, we were expecting low levels of satisfaction regarding the ease of update.`,
        date: new Date().toLocaleString(),
        category: "news"
      },
      { 
        title: "ReactJS News - Using Proxies with Redux Types", 
        body: `One of the most common problems that I run into when using Redux is trying to figure out why an action is not being captured by a reducer. For someone just getting starting with Redux, debugging this issue can be especially overwhelming because of how Redux manages data flow. 
        
        So before you start pouring over configuration code, or the logic contained in your action creators and reducers, please, make sure your action types are defined and spelled correctly.
        
        Proxies are a feature of ES2015 that allow us to customize operations on a object. They can be used in many different ways, and you can find some useful examples here and here. For our problem, this example from Mozilla looks promising:
        
        So if proxies can be used to validate that properties assigned to an object are of a certain type and value, we should definitely be able to ensure that our action types are never undefined, or else throw an error that will be easy for us to fix. Let’s refactor our actionTypes.js file.`,
        date: new Date().toLocaleString(),
        category: "news"
      }
    ]
    
  
  }

  ngAfterViewInit(){
    const elems = document.querySelectorAll('.carousel');
    const instances = Materialize.Carousel.init(elems, this.options);

    // const indicators= document.querySelector(".indicators");
    // indicators.setAttribute('class', 'indicators');

    // console.log(indicators)
  }

  popup(news: News){
    const dialogRef = this.dialog.open(NewsDialogComponent, {
      width: '80%',
      data: news
    });
  }


}
