import { DataService } from './../services/data.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';

import { AuthService } from './../services/auth.service';
import { MatSelectChange } from "@angular/material/select";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  hide = true;
  isChecked = true;
  userdetail: any;
  roles: any;
  message: {error?: string; message?: string} = {};
  subscription: Subscription;
  isDisabled = false;
  arrayList:any;

  constructor(
    private authService: AuthService,
    private router: Router,
    private data: DataService) {}

  async ngOnInit() {
  // ngOnInit() {

    try {
      const result  = await this.data.getRoles();

      const roles = Object.keys(result.data[0]);
      // console.log(roles)

      this.roles = roles.slice(1, 3);
      console.log(this.roles);
    } catch (e) {

    }

    this.arrayList = [
      {name: 'Trainer'},
      {name: 'Trainee'}
    ]
  }

  getRole(event){
    console.log(event);
  }

  onSubmit(form) {
    // console.log(form.position);
    // this.isDisabled = true;
    // if(form.position === 'Trainer'){
    //   this.router.navigate(['/lecturer/dashboard']);
    // }else if(form.position === 'Trainee'){
    //   this.router.navigate(['/student/dashboard']);
    // }else{
    //   console.log('position not match');
    // }
    this.isDisabled = true;
    this.subscription = this.authService.login(form)
      .subscribe(result => {
        this.authService.isLoggedIn();

        if (result.success) {
          const user = this.authService.loggedInUser();
          
          switch (user.position) {
            case 'student':
              this.router.navigateByUrl('/student/dashboard');
              break;

           case 'lecturer':
              this.router.navigateByUrl('/lecturer/dashboard');
              break;

            default: {
              console.log('No matched position');
              this.message.error = 'Could not redirect at this time';
              break;
            }
          }
        } else {
          if (!result.success) {
            if (!result.message) {
              this.message.error = 'Could not login at this time';
            } else {
              this.message.message = result.message;
              this.isDisabled = false;
            }
          }
        }
      });
  }

  onDestroy() {
    this.subscription.unsubscribe();
  }

  async getRoles() {

  }

}
