export interface Assignment{
    _id: string;
    courseName?: string;
    status: string;
    dueDate: string;
    courseCode?: string;
  }