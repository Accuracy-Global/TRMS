export interface DialogData{
    file: string;
    title: string;
  }