export interface LoginDetail{
    email?: string;
    matric?: string;
    lecturerId?: string;
    password: string;
    referenceNo: string;
    position: String
  }