export interface News{
    title: string;
    body: string;
    date: string;
    category: string;
}