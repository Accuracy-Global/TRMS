export interface ServerResponse{
    success?: boolean;
    message?: string;
    data?: any;
    token?: string;
}